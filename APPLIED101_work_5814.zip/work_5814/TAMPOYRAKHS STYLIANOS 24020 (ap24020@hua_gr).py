import os
import time

# Λίστα με όλα τα τονισμένα ελληνικά γράμματα
tonos_letters = "ΆΈΉΊΌΎΏάέήίόύώ"

# Στάδια της κρεμάλας σε ASCII
kremmala_stages = [
    """
     +---+
     |   |
         |
         |
         |
         |
    =========""",
    """
     +---+
     |   |
     O   |
         |
         |
         |
    =========""",
    """
     +---+
     |   |
     O   |
     |   |
         |
         |
    =========""",
    """
     +---+
     |   |
     O   |
    /|   |
         |
         |
    =========""",
    """
     +---+
     |   |
     O   |
    /|\  |
         |
         |
    =========""",
    """
     +---+
     |   |
     O   |
    /|\  |
    /    |
         |
    =========""",
    """
     +---+
     |   |
     O   |
    /|\  |
    / \  |
         |
    =========""",
]

def clear_screen():
    print("\n" * 50)  # "Καθαρίζει" την οθόνη σε Thonny
    os.system('cls' if os.name == 'nt' else 'clear')  # Windows/Linux/Mac

# ASCII text για το "GAME OVER"
def show_game_over():
    clear_screen()
    game_over_ascii = [
    "░▒▓█▓▒░      ░▒▓██████▓▒░ ░▒▓███████▓▒░▒▓████████▓▒░▒▓███████▓▒░░▒▓█▓▒░▒▓█▓▒░▒▓█▓▒░▒▓█▓▒░ ",
        "░▒▓█▓▒░     ░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░      ░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░▒▓█▓▒░▒▓█▓▒░▒▓█▓▒░ ",
        "░▒▓█▓▒░     ░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░      ░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░▒▓█▓▒░▒▓█▓▒░▒▓█▓▒░ ",
        "░▒▓█▓▒░     ░▒▓█▓▒░░▒▓█▓▒░░▒▓██████▓▒░░▒▓██████▓▒░ ░▒▓███████▓▒░░▒▓█▓▒░▒▓█▓▒░▒▓█▓▒░▒▓█▓▒░ ",
        "░▒▓█▓▒░     ░▒▓█▓▒░░▒▓█▓▒░      ░▒▓█▓▒░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░▒▓█▓▒░▒▓█▓▒░▒▓█▓▒░ ",
        "░▒▓█▓▒░     ░▒▓█▓▒░░▒▓█▓▒░      ░▒▓█▓▒░▒▓█▓▒░      ░▒▓█▓▒░░▒▓█▓▒░                         ",
        "░▒▓████████▓▒░▒▓██████▓▒░░▒▓███████▓▒░░▒▓████████▓▒░▒▓█▓▒░░▒▓█▓▒░▒▓█▓▒░▒▓█▓▒░▒▓█▓▒░▒▓█▓▒░ ",
    ]
    for line in game_over_ascii:
        print(line)
    time.sleep(3)
    
    
# ASCII text για το "WIN"
def show_win():
    clear_screen()
    win_ascii = [
        "  \\o       o/   o__ __o        o         o        o              o   __o__   o          o  ",
        "  v\\     /v   /v     v\\      <|>       <|>      <|>            <|>    |    <|\\        <|>    ",
        "   <\\   />   />       <\\     / \\       / \\      / \\            / \\   / \\   / \\\\o      / \\    ",
        "     \\o/   o/           \\o   \\o/       \\o/      \\o/            \\o/   \\o/   \\o/ v\\     \\o/    ",
        "      |   <|             |>   |         |        |              |     |     |   <\\     |     ",
        "     / \\   \\\\           //   < >       < >      < >            < >   < >   / \\    \\o  / \\    ",
        "     \\o/     \\         /      \\         /        \\o    o/\\o    o/     |    \\o/     v\\ \\o/    ",
        "      |       o       o        o       o          v\\  /v  v\\  /v      o     |       <\\ |     ",
        "     / \\      <\\__ __/>        <\\__ __/>           <\\/ >    <\\/ >   __|>_  / \\        < \\    ",
    ]
    for line in win_ascii:
        print(line)
    time.sleep(3)

# Συνάρτηση που ελέγχει αν ο παίκτης κέρδισε ή έχασε
def check_win_or_loss(tries, hidden_word, hword):
    if hidden_word == hword:
        show_win()
        return True
    elif tries == 0:
        show_game_over()
        print("Η λέξη ήταν:", hword)
        return True
    return False 

def kremmala():
    while True:
        hword = input("Δώσε μία λέξη ή φράση (χωρίς τόνους): ").upper()
        
        if any(letter in tonos_letters for letter in hword):
            print("Η λέξη περιέχει τόνους! Δοκίμασε ξανά χωρίς τόνους.")
            continue

        if not hword.replace(" ", "").isalpha():
            print("Επιτρέπονται μόνο γράμματα και κενά. Δοκίμασε ξανά.")
            continue
        
        print("Έγκυρη λέξη/φράση! " + "*" * len(hword))
        time.sleep(1)
        clear_screen()
        break  

    tries = 6
    letters = []  

    def hide():
        hidden = ''
        for letter in hword:
            if letter in letters or letter == " ":
                hidden += letter
            else:
                hidden += '-'
        return hidden

    hidden_word = hide()
    print(hidden_word)
    print(kremmala_stages[6 - tries])

    while tries > 0:
        choice = input("Θέλεις να δοκιμάσεις ένα γράμμα (Γ) ή να μαντέψεις όλη τη λέξη (Λ); ").upper()

        if choice == 'Λ':
            guess = input("Γράψτε όλη τη λέξη: ").upper()
            if guess == hword:
                hidden_word = hword
            else:
                print("Λάθος λέξη! Χάνετε μία προσπάθεια.")
                tries -= 1  

        elif choice == 'Γ':  
            letter = input("Γράμμα; ").upper()

            if len(letter) != 1 or not letter.isalpha():
                print("Μη έγκυρη επιλογή. Πληκτρολόγησε ένα μόνο γράμμα.")
                continue

            if letter in letters:
                print("Έχετε δοκιμάσει ήδη αυτό το γράμμα.")
                continue  

            letters.append(letter)

            if letter in hword:
                print("Το γράμμα υπάρχει!")
            else:
                print("Το γράμμα δε βρέθηκε.. Χάνετε μία προσπάθεια.")
                tries -= 1  

            hidden_word = hide()
            print(hidden_word)
        
        else:  
            print("Μη έγκυρη επιλογή. Πληκτρολόγησε 'Γ' για γράμμα ή 'Λ' για λέξη.")
            continue

        print(kremmala_stages[6 - tries])  
        print(f"Απομένουν {tries} προσπάθειες.")

        if check_win_or_loss(tries, hidden_word, hword):
            break

    while True:
        restart = input("\nΘες να ξαναπαίξεις; (Ναι/Όχι): ").strip().lower()
        if restart == "ναι":
            clear_screen()
            kremmala()
        elif restart == "οχι":
            print("Ευχαριστούμε που έπαιξες!")
            exit()
        else:
            print("Μη έγκυρη επιλογή. Πληκτρολόγησε 'Ναι' ή 'Όχι'.")

kremmala()
