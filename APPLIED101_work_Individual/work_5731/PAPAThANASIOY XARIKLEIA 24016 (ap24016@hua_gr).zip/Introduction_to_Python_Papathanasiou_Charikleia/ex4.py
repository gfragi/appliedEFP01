#Δημιουργήστε μια συνάρτηση που παίρνει μια λίστα αριθμών και επιστρέφει:
#Το μέγιστο
#Το ελάχιστο
#Τη μέση τιμή
#Δοκιμάστε τη συνάρτηση με λίστα που δίνει ο χρήστης.

import math
user_input = input("Enter elements separated by space: ").split()
for i in range(len(user_input)):
    user_input[i] = int(user_input[i])
def operations(user_input):
    maximum_number = max(user_input)
    print("Maximum: ", maximum_number)
    minimum_number = min(user_input)
    print ("Minimum: ", minimum_number)
    avg_number = int(sum(user_input)/len(user_input))
    print ("Average: ", avg_number)
operations(user_input)
