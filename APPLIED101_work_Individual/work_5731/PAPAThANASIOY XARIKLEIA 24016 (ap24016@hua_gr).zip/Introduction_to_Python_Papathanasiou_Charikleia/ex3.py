#Δημιουργήστε μια συνάρτηση που υπολογίζει το κόστος ενός προϊόντος με ΦΠΑ.
#Επιστρέψτε τόσο το τελικό ποσό όσο και το ποσό του ΦΠΑ.
#Η συνάρτηση θα πρέπει να δέχεται την τιμή του προϊόντος και τον συντελεστή ΦΠΑ.
#Παίρνω από το χρήστη τα απαραίτητα στοιχεία

price = int(input("Give price: "))
vat = float(input("Pleae give Vat: "))
def cost(price, vat):
    total_vat = price * vat
    total_cost = total_vat + price
    print("Initial value: ", price, "Vat: ", vat, "Total Vat: ", total_vat, "Final cost: ", total_cost)

print(cost(price, vat))
