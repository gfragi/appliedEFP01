#Δημιουργήστε ένα πρόγραμμα που υπολογίζει το υπόλοιπο της διαίρεσης δύο αριθμών.
#Αν το υπόλοιπο είναι μεγαλύτερο από έναν τρίτο αριθμό που δίνεται από τον χρήστη, εκτυπώστε ένα κατάλληλο μήνυμα.

def modulo(x,y):
    r=x%y
    return r
a= int(input("Please give a number: "))
if a> modulo(10,7):
    print("Your given number is bigger than the modulo of the division 10/7")
