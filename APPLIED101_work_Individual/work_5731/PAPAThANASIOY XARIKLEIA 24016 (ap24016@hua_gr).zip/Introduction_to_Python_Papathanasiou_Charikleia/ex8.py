#Δημιουργήστε ένα πρόγραμμα που υπολογίζει αν ένας αριθμός είναι:
#Πρώτος αριθμός
#Τέλειος αριθμός (το άθροισμα των διαιρετών του εκτός από τον ίδιο είναι ίσο με τον αριθμό)
#Εμφανίστε κατάλληλα μηνύματα.



def is_prime(n):
    if n<2:
        return "The entered number is not prime"
    for x in range (2,n-1):
        if n%x==0:
            return "The entered number is not prime"
    return "The entered number is prime"

def is_perfect(n):
    sum_p=0
    for i in range(1,n):
        if (n%i==0):
            sum_p=sum_p+i  
    if(sum_p==n):  
        return "The entered number is a perfect number"  
    else:  
        return "The entered number is not a perfect number"
