#Δημιουργήστε ένα λεξικό όπου τα κλειδιά είναι τα ονόματα των φοιτητών και οι τιμές είναι οι βαθμοί τους.
#Εμφανίστε τους φοιτητές που πέρασαν το μάθημα (βαθμός >= 50).

students_data  = {'Mary' : 80, 'Filip': 76, 'Matthew' : 54, 'Lisa' : 34, 'Katy' : 69}
passed = []
for key, value in students_data.items():
    if value >= 50:
        passed.append(key)
print(passed)
