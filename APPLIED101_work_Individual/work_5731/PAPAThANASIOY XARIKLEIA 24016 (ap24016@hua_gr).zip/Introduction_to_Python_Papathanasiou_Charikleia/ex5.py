#Δημιουργήστε μια λίστα με αριθμούς που δίνει ο χρήστης και αφαιρέστε τους αριθμούς που είναι μικρότεροι από το μέσο όρο.
#Εμφανίστε την τελική λίστα.


user_input = input("Enter elements separated by space: ").split()
for i in range(len(user_input)):
    user_input[i] = int(user_input[i])
avg_number = int(sum(user_input)/len(user_input))
num_list = [i for i in user_input if i > avg_number]
print(num_list)
