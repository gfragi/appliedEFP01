#Υπολογίστε τη μέση βαθμολογία ανά εξάμηνο από το DataFrame της προηγούμενης άσκησης.

import pandas as pd
import numpy as np
students_data  = {'name': ['Mary', 'Filip', 'Matthew', 'Lisa', 'Katy'],
        'grade': [80, 76, 54, np.nan, 69],
        'semester': ["A", "C", "A", "D", "B"]}
labels = [1, 2, 3, 4, 5]

df = pd.DataFrame(students_data , index=labels)
print("\nMean grade:")
print(df['grade'].mean())
