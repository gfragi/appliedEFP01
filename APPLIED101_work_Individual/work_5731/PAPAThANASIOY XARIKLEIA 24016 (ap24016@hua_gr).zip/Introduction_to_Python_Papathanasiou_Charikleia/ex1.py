#Υπολογίστε το μέσο όρο, το γινόμενο, και τη διαφορά των τετραγώνων των αριθμών που δίνει ο χρήστης (τουλάχιστον 3 αριθμοί).
#Ζητήστε είσοδο αριθμών, και αποθηκεύστε τα αποτελέσματα σε μεταβλητές.

a=int(input("Please give the first number: "))
a**=2
b=int(input("Please give the second number: "))
b**=2
c=int(input("Please give the third number: "))
c**=2
mean=(a+b+c)/3
mult=a*b*c
sub=a-b-c
print("Mean is:", mean, "Multiplication is:", mult, "Subtraction is:", sub)
      
